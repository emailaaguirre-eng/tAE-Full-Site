<?php
// Fallback index for the theme.
get_header();
?>
<main class="section-main" style="min-height: 50vh; padding: 4rem 1.5rem;">
  <h1 style="margin:0;">The Artful WP Theme</h1>
  <p>Customize with blocks/ACF. Sections: use .section-main and .section-alt for alternating backgrounds.</p>
</main>
<?php get_footer(); ?>

